#!/bin/bash
for i
    do echo $1
       shift
done
